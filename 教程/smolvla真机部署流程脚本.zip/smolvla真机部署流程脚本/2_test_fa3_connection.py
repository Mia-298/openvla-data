# test_fa3_connection.py
"""
测试法奥3机械臂SDK连接和基本通信。
在运行前请确保:
1. 法奥3控制器已开机
2. 电脑与控制器在同一网段 (默认 192.168.58.x)
3. Robot.py 在当前目录或PYTHONPATH中
"""
import sys
import time

# 如果你的SDK不在当前目录，可以在这里添加路径
# sys.path.append("/path/to/fairino/sdk")

def test_connection(ip="192.168.58.2"):
    """
    功能：完整测试法奥3机械臂的网络连接、状态读取、通信延迟
    参数：ip - 机械臂控制器IP地址（默认192.168.58.2）
    """
    print("=" * 60)
    print(f"测试法奥3连接 (IP: {ip})")
    print("=" * 60)
    
    # ===================== 1. 导入机械臂SDK =====================
    print("\n[1] 导入法奥的Robot模块...")
    try:
        # 法奥3官方Python SDK
        from Robot import RPC
        print("  [OK] 法奥的Robot导入成功")
    except ImportError as e:
        print(f"  [FAIL] 无法导入frrpc: {e}")
        print("  请确保Robot.py在当前目录或PYTHONPATH中")
        return  # 导入失败直接退出
    
    # ===================== 2. 创建RPC连接 =====================
    print(f"\n[2] 连接到机器人 {ip}...")
    try:
        # 创建RPC客户端，连接机械臂控制器
        robot = RPC(ip)
        time.sleep(1.5)  # 等待连接线程稳定
    except Exception as e:
        print(f"  [FAIL] 连接失败: {e}")
        return  # 连接失败直接退出
    
    # ===================== 3. 检查是否真的连上 =====================
    print("\n[3] 检查连接状态...")
    if RPC.is_conect:
        print("  [OK] XML-RPC连接正常")
    else:
        print("  [FAIL] XML-RPC连接失败，请检查网络")
        return
    
    # ===================== 4. 获取SDK版本 =====================
    print("\n[4] 获取SDK版本...")
    try:
        err, ver = robot.GetSDKVersion()
        if err == 0:
            print(f"  [OK] SDK版本: {ver}")
        else:
            print(f"  [WARN] 获取版本返回错误码: {err}")
    except Exception as e:
        print(f"  [FAIL] 获取版本异常: {e}")
    
    # ===================== 5. 读取6个关节角度 =====================
    print("\n[5] 读取当前关节位置...")
    try:
        # 获取关节角度（单位：度）
        err, joints = robot.GetActualJointPosDegree()
        if err == 0:
            print(f"  [OK] 关节角度(°):")
            names = ["J1", "J2", "J3", "J4", "J5", "J6"]
            # 打印6个关节的角度
            for name, val in zip(names, joints):
                print(f"    {name}: {val:.3f}°")
        else:
            print(f"  [FAIL] 读取关节位置错误码: {err}")
    except Exception as e:
        print(f"  [FAIL] 读取关节位置异常: {e}")
    
    # ===================== 6. 读取末端位姿 =====================
    print("\n[6] 读取当前TCP位姿...")
    try:
        # 获取TCP（工具末端）位姿
        err, tcp = robot.GetActualTCPPose()
        if err == 0:
            print(f"  [OK] TCP位姿:")
            labels = ["X(mm)", "Y(mm)", "Z(mm)", "RX(°)", "RY(°)", "RZ(°)"]
            # XYZ：空间坐标
            # RX RY RZ：姿态角
            for label, val in zip(labels, tcp):
                print(f"    {label}: {val:.3f}")
        else:
            print(f"  [FAIL] 读取TCP错误码: {err}")
    except Exception as e:
        print(f"  [FAIL] 读取TCP异常: {e}")
    
    # ===================== 7. 读取机器人运行状态 =====================
    print("\n[7] 读取机器人运行状态...")
    try:
        err, state = robot.GetProgramState()
        # 状态对照表
        state_map = {1: "停止", 2: "运行", 3: "暂停"}
        print(f"  [OK] 程序状态: {state_map.get(state, f'未知({state})')}")
    except Exception as e:
        print(f"  [WARN] {e}")
    
    # ===================== 8. 检查是否有错误码 =====================
    print("\n[8] 检查机器人错误码...")
    try:
        err, codes = robot.GetRobotErrorCode()
        if err == 0:
            # codes[0]主错误码  codes[1]子错误码
            if codes[0] == 0 and codes[1] == 0:
                print(f"  [OK] 无错误")
            else:
                print(f"  [WARN] 主错误码={codes[0]}, 子错误码={codes[1]}")
    except Exception as e:
        print(f"  [WARN] {e}")
    
    # ===================== 9. 测试通信延迟（性能测试） =====================
    print("\n[9] 测试关节读取延迟 (100次)...")
    latencies = []
    for _ in range(100):
        t0 = time.perf_counter()
        err, _ = robot.GetActualJointPosDegree()
        dt = (time.perf_counter() - t0) * 1000  # 转毫秒
        if err == 0:
            latencies.append(dt)
    
    if latencies:
        avg = sum(latencies) / len(latencies)
        mn = min(latencies)
        mx = max(latencies)
        print(f"  [OK] 平均={avg:.2f}ms, 最小={mn:.2f}ms, 最大={mx:.2f}ms")

    # ===================== 10. 测试夹爪 =====================
    print("\n[10] 夹爪测试...")
    # 激活夹爪
    err=robot.ActGripper(1,1)
    if err == 0:
        print("夹爪激活成功")
    else:
        print("夹爪激活失败")
    # 控制夹爪卡开合
    err=robot.MoveGripper(1,50,30,50,5000,0,0,0,50,50)
    if err == 0:
        print("夹爪控制成功")
    else:
        print("夹爪控制失败")
    # 获取夹爪位置
    err,done_g,pos_g=robot.GetGripperCurPosition() 
    if err == 0:
        if done_g == 0:
            print("夹爪调用成功")
            print(f"返回夹爪位置百分比：{pos_g}")
        else:
            print("夹爪调用有错误")
        
    # ===================== 11. 关闭连接 =====================
    print("\n[11] 关闭连接...")
    try:
        robot.CloseRPC()
        print("  [OK] 连接已关闭")
    except Exception as e:
        print(f"  [WARN] 关闭异常: {e}")
    
    # 最终结果
    print("\n" + "=" * 60)
    print("连接测试完成!")
    print("=" * 60)

# 程序入口
if __name__ == "__main__":
    # 支持命令行传入IP，否则使用默认 192.168.58.2
    ip = sys.argv[1] if len(sys.argv) > 1 else "192.168.58.2"
    test_connection(ip)
