# test_fa3_with_camera.py
"""
同步测试法奥3关节读取 + 摄像头读取
功能：
    1. 同时读取机械臂6轴角度
    2. 同时读取摄像头画面
    3. 统计延迟、FPS
    4. 模拟 LeRobot 数据采集循环

这是训练前必须通过的关键测试！
"""
import sys
import time
import cv2

def test_sync(ip="192.168.58.2", cam_index=6, fps=30, duration=5):
    """
    同步采集测试主函数
    :param ip: 机械臂IP
    :param cam_index: 摄像头编号（你是 6）
    :param fps: 目标帧率
    :param duration: 测试时长（秒）
    """
    from Robot import RPC
    
    # ===================== 1. 连接机械臂 =====================
    print(f"连接机器人 {ip}...")
    robot = RPC(ip)
    time.sleep(1.5)  # 等待连接稳定
    
    if not RPC.is_conect:
        print("[FAIL] 机器人连接失败")
        return

    # ===================== 2. 打开摄像头 =====================
    print(f"打开摄像头 index={cam_index}...")
    
    # 强制V4L2后端（你之前测试成功的方式）
    cap = cv2.VideoCapture(cam_index, cv2.CAP_V4L2)
    
    if not cap.isOpened():
        print(f"[FAIL] 摄像头打开失败")
        robot.CloseRPC()
        return

    # 设置摄像头分辨率 640x480
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    # ===================== 3. 开始同步采集 =====================
    print(f"开始同步采集 ({duration}秒, 目标{fps}FPS)...")

    frame_count = 0         # 成功采集帧数
    joint_times = []        # 记录机械臂读取延迟
    cam_times = []          # 记录摄像头读取延迟
    total_times = []        # 记录一整个循环的延迟

    t_start = time.perf_counter()  # 记录开始时间

    # 持续采集，直到达到设定时长
    while time.perf_counter() - t_start < duration:
        t0 = time.perf_counter()  # 循环开始时间戳

        # -------------------- 读取机械臂关节 --------------------
        t_j0 = time.perf_counter()
        err, joints = robot.GetActualJointPosDegree()  # 读取6轴角度
        t_j1 = time.perf_counter()
        joint_times.append((t_j1 - t_j0) * 1000)  # 转毫秒保存

        # -------------------- 读取摄像头画面 --------------------
        t_c0 = time.perf_counter()
        ret, frame = cap.read()  # 读取一帧图像
        t_c1 = time.perf_counter()
        cam_times.append((t_c1 - t_c0) * 1000)

        # 如果两者都成功，算有效帧
        if err == 0 and ret:
            frame_count += 1

        # 记录整个循环耗时
        total_times.append((time.perf_counter() - t0) * 1000)

        # -------------------- FPS 控制（稳定帧率） --------------------
        dt = time.perf_counter() - t0
        sleep_time = 1.0 / fps - dt  # 计算需要等待的时间
        if sleep_time > 0:
            time.sleep(sleep_time)

    # ===================== 4. 采集结束，释放资源 =====================
    cap.release()
    robot.CloseRPC()

    # ===================== 5. 输出统计结果 =====================
    actual_fps = frame_count / duration
    
    print(f"\n========== 同步采集测试结果 ==========")
    print(f"  成功采集帧数: {frame_count}")
    print(f"  实际FPS: {actual_fps:.1f}")
    print(f"  关节读取延迟: 平均{sum(joint_times)/len(joint_times):.1f}ms")
    print(f"  摄像头读取延迟: 平均{sum(cam_times)/len(cam_times):.1f}ms")
    print(f"  总循环延迟: 平均{sum(total_times)/len(total_times):.1f}ms")

    # 判断帧率是否达标
    if actual_fps >= fps * 0.8:
        print(f"  [OK] FPS 达标！可以用于训练")
    else:
        print(f"  [WARN] FPS 不足，需要降低帧率或优化系统")

# ===================== 程序入口 =====================
if __name__ == "__main__":
    ip = sys.argv[1] if len(sys.argv) > 1 else "192.168.58.2"
    
    # 注意：你的摄像头是 index=6
    test_sync(ip, cam_index=6, fps=30, duration=5)
