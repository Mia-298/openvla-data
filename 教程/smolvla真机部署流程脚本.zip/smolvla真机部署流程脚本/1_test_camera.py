# test_camera_gui.py
"""
摄像头测试 - 带GUI画面显示
检测到可用摄像头后自动弹出窗口实时显示画面
index=6是我正常可用的彩色RGB接口
"""
import cv2
import sys
import numpy as np

def test_opencv_camera(index):
    """测试普通USB摄像头，并弹出GUI窗口显示画面"""
    print(f"\n--- 测试OpenCV摄像头 index={index} (V4L2后端) ---")
    
    # 强制使用V4L2后端
    cap = cv2.VideoCapture(index, cv2.CAP_V4L2)
    if not cap.isOpened():
        print(f"  [FAIL] V4L2方式无法打开 index={index}")
        return False
    
    # 获取摄像头参数
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    backend = cap.getBackendName()
    print(f"  [INFO] 分辨率={w}x{h}, FPS={fps}, 后端={backend}")
    
    # 设置分辨率
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    # ===================== 【核心改动】开启GUI实时显示 =====================
    print(f"  [OK] 正在打开摄像头画面窗口...")
    print(f"  按 Q 键关闭当前窗口，继续测试下一个摄像头")
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            print(f"  [WARN] 读取帧失败")
            break
        
        frame_count += 1
        # 在画面上显示信息
        info = f"Cam {index} | 640x480 | Frame {frame_count}"
        cv2.putText(frame, info, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # 弹出窗口显示画面
        cv2.imshow(f"Camera {index}", frame)

        # 按键操作
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break  # 按 Q 关闭当前窗口
        elif key == 27:
            # 按 ESC 直接退出整个程序
            cap.release()
            cv2.destroyAllWindows()
            sys.exit(0)

    # 释放资源
    cap.release()
    cv2.destroyAllWindows()
    print(f"  [OK] 成功读取 {frame_count} 帧")
    return frame_count > 0


def list_video_devices():
    """列出系统中的视频设备"""
    print("\n--- 系统视频设备 ---")
    import glob
    devices = sorted(glob.glob("/dev/video*"))
    for dev in devices:
        print(f"  {dev}")
    
    print("\n--- USB设备 ---")
    import subprocess
    result = subprocess.run(["lsusb"], capture_output=True, text=True)
    for line in result.stdout.split("\n"):
        if "Orbbec" in line:
            print(f"  {line.strip()}")


def main():
    print("=" * 60)
    print("摄像头测试工具 (GUI画面版)")
    print("=" * 60)
    
    list_video_devices()
    
    # 测试 0~4 号摄像头
    v4l2_results = {}
    for i in range(10):
        v4l2_results[i] = test_opencv_camera(i)
    
    # 结果汇总
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    for idx, ok in v4l2_results.items():
        status = "✓ 可用" if ok else "✗ 不可用"
        print(f"  OpenCV V4L2 index={idx}: {status}")
    
    print("\n✅ 你的可用摄像头: index = 2 和 4")
    print("👉 建议在 LeRobot 项目中使用 CAMERA_INDEX=2")

if __name__ == "__main__":
    main()
