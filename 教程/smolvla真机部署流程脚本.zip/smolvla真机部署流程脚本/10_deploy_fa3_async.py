# 10_deploy_fa3_async.py
"""
SmolVLA异步推理部署到法奥3机械臂。
- 主线程: 100Hz固定频率从action队列取动作, 发送ServoJ（刚性控制）
- 推理线程: 后台持续调用模型, 将输出的action chunk填入队列
- 摄像头线程: 持续读取最新帧，保证视觉实时性

用法:
  python 10_deploy_fa3_async.py \
    --policy-path outputs/fa3_smolvla_finetune/checkpoints/last/pretrained_model \
    --task "pick up the blue block and place it into the box"
"""
import argparse
import sys
import time
import cv2
import threading
import numpy as np
import torch
from collections import deque

# 法奥机器人SDK
from Robot import RPC

# 模型输入图像尺寸（必须和训练时一致）
IMG_SIZE = 256
# 状态向量含义：6个关节 + 夹爪
STATE_NAMES = ["j1", "j2", "j3", "j4", "j5", "j6", "gripper"]


# ==============================================================================
# 摄像头独立线程：持续采集图像，不阻塞主控制
# ==============================================================================
class CameraThread:
    def __init__(self, cam_idx):
        # 打开摄像头（V4L2用于Linux低延迟）
        self.cap = cv2.VideoCapture(cam_idx, cv2.CAP_V4L2)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)

        # 最新图像缓存 + 线程锁
        self.latest_frame = None
        self.lock = threading.Lock()
        self.running = True

        # 启动后台线程
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def _loop(self):
        """后台持续读帧，只保留最新一帧，频率是30hz"""
        while self.running:
            ret, frame = self.cap.read()
            if ret:
                with self.lock:
                    self.latest_frame = frame

    def get_frame(self):
        """获取最新图像（线程安全）"""
        with self.lock:
            return self.latest_frame.copy() if self.latest_frame is not None else None

    def stop(self):
        """停止线程并释放摄像头"""
        self.running = False
        self.thread.join(timeout=2)
        self.cap.release()


# ==============================================================================
# 模型推理独立线程：后台跑SmolVLA，输出动作存入队列
# ==============================================================================
class InferenceThread:
    """
    【你自研的 正确版 异步推理线程】
    核心设计思想：
    1. 推理线程不高频调用，而是**按需推理**（队列快空了才推理）
    2. 每次推理强制产出 **一整个 chunk（50步动作）**
    3. 一次性把 50 步全部推入队列
    4. 主线程 100Hz 匀速消费
    5. 推理线程提前预判、提前生产 → 绝对不会断帧
    """
    def __init__(self, policy, preprocessor, postprocessor, device,
                 camera, robot, task):
        # 模型、预处理、后处理、计算设备
        self.policy = policy
        self.preprocessor = preprocessor
        self.postprocessor = postprocessor
        self.device = device

        # 外部硬件：相机、机械臂、任务指令
        self.camera = camera
        self.robot = robot
        self.task = task

        # 【线程安全动作队列】最大缓存200步动作，足够缓冲
        self.action_queue = deque(maxlen=200)
        self.lock = threading.Lock()
        self.running = True

        # 调试信息：推理次数、耗时
        self.inference_count = 0
        self.last_inference_ms = 0

        # 【核心：自动读取模型训练时固定的 chunk 长度】默认50步
        self.chunk_size = getattr(policy.config, 'chunk_size', 50)
        print(f"  模型chunk_size: {self.chunk_size} (一次推理产出{self.chunk_size}步动作)")

        # 启动后台推理线程
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
#######################################################################################
         # 时间集成相关
        self.all_actions_buffer = []  # 存储多个chunk，每个chunk带时间戳
        self.ensemble_queue = deque(maxlen=200)  # 最终输出的平滑动作队列
        self.global_step_counter = 0  # 全局步数计数器
        self.overlap_steps = 10  # chunk之间的重叠步数
    
        # 时间集成权重：越靠后的chunk权重越高（指数衰减）
        self.temporal_weight_decay = 0.01  # k值，越小越平滑

        # 【新增】软件维护的夹爪状态，由主线程更新
        self.software_grip_state = 0.0  # 0.0=张开, 1.0=闭合
        self.grip_state_lock = threading.Lock()

    # 新增解决夹爪问题
    def set_grip_state(self, state):
        """主线程调用：更新夹爪状态"""
        with self.grip_state_lock:
            self.software_grip_state = state
    
    # 新增解决夹爪问题
    def get_grip_state(self):
        """推理线程调用：获取夹爪状态"""
        with self.grip_state_lock:
            return self.software_grip_state

    # 新增时间集成相关
    def _compute_temporal_weights(self, num_steps):
        """计算时间集成权重，越早的步越权重低"""
        weights = np.exp(-self.temporal_weight_decay * np.arange(num_steps))
        return weights
    def _loop(self):
        """改进的推理循环"""
        while self.running:
            with self.lock:
                remaining = len(self.action_queue)
            
            # 队列充足时不推理
            if remaining > 20:
                time.sleep(0.01)
                continue
            
            t0 = time.perf_counter()
            try:
                # 获取观测（同原代码）
                frame = self.camera.get_frame()
                err, actual_joints = self.robot.GetActualJointPosDegree()

                # 原本夹爪的状态是直接从硬件读取，但是读取有问题（会有严重的滞后性和）——不能使用了
                # actual_grip = float(self.robot.robot_state_pkg.gripper_position) / 100.0

                # ============================================
                # 【关键修改】不从硬件读夹爪，用软件状态
                # ============================================
                actual_grip = self.get_grip_state()  # 0.0 或 1.0，完美二值
                
                if frame is None or err != 0:
                    time.sleep(0.01)
                    continue
                
                state_7d = list(actual_joints) + [actual_grip]
                frame_resized = cv2.resize(frame, (IMG_SIZE, IMG_SIZE))
                frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
                
                obs_dict = {
                    "observation.images.top": (
                        torch.from_numpy(frame_rgb).permute(2, 0, 1)
                        .unsqueeze(0).float().to(self.device) / 255.0
                    ),
                    "observation.state": (
                        torch.from_numpy(np.array(state_7d, dtype=np.float32))
                        .unsqueeze(0).to(self.device)
                    ),
                    "task": self.task,
                }
                
                obs_processed = self.preprocessor(obs_dict)
                # 重置模型状态（清除上一轮推理的缓存），因为默认一次推理50步，会缓存起来，我只用30步，所以每次重新推理前，都需要把上一次推理产生的缓存都清空一下
                self.policy.reset()
                
                # 取完整chunk
                chunk_actions = []# 空列表，用来装模型生成的每一步动作（7个值：6关节+1夹爪）
                # 最多使用30步（模型预测50步，但太远不准，只取前30步）
                use_steps = min(30, self.chunk_size)

                # 循环 chunk_size 次（通常50次），让模型从模型推理的50步动作中取前30步
                for i in range(self.chunk_size):
                    # 推理阶段：禁用梯度计算（提速、省显存、不修改模型权重）
                    with torch.no_grad():
                        # 模型的预测（一次预测会产生50步动作，会存在缓存中，但是select_action一次只会选一步出来，所以要循环取）
                        t1=time.perf_counter()
                        action = self.policy.select_action(obs_processed)
                        interface_time_true= (time.perf_counter() - t1) * 1000
                        # print(f"实际推理一次需要的时间：{interface_time_true}")
                    
                    # （反归一化：从 [-1,1] 还原成真实关节角度）
                    action = self.postprocessor(action)

                    # ====================== 5. 统一数据格式（关键） ======================
                    # 兼容所有模型输出格式：
                    # 不管模型输出是 dict / tensor / array
                    # 最终全部转成：一维 numpy 数组 (7,)
                    # isinstance 就是用来检查：「这个变量，到底是什么类型的东西？」，用法：isinstance(变量, 类型)，返回结果True、False
                    if isinstance(action, dict) and "action" in action:
                         # 模型输出包装成字典 → 取出 action tensor → 转CPU → 转numpy → 展平
                        action_np = action["action"].cpu().numpy().flatten()
                    # 如果模型输出是张量
                    elif isinstance(action, torch.Tensor):
                         # 直接输出 tensor → 转CPU → 转numpy → 展平
                        action_np = action.cpu().numpy().flatten()
                    else:
                         # 兜底：直接转成 numpy 数组
                        action_np = np.array(action).flatten()
                    # 模型虽然跑了50次循环，但只保存前30步（后面丢弃）
                    if i < use_steps:
                        chunk_actions.append(action_np)

                # 得到了新一次推理的新action_chunk
                chunk_actions = np.array(chunk_actions)  # shape: (use_steps, 7)
                
                # 通过时间集成机制，把新旧chunk做一个平滑的过渡
                # ========== 时间集成核心逻辑 ==========
                with self.lock:
                    # 记录当前队列中还有多少步没消费
                    old_remaining = len(self.action_queue)
                    
                    if old_remaining == 0:
                        # 队列空了，直接放入新chunk（没有重叠可做）
                        for a in chunk_actions:
                            self.action_queue.append(a)
                    else:
                        # 取出队列中剩余的旧动作
                        old_actions = list(self.action_queue)
                        self.action_queue.clear()
                        
                        # 计算重叠区域长度
                        overlap = min(len(old_actions), len(chunk_actions))
                        
                        # 对重叠部分做加权平均
                        for i in range(overlap):
                            # 旧动作权重随时间递减，新动作权重递增
                            w_new = (i + 1) / (overlap + 1)  # 线性插值
                            w_old = 1.0 - w_new
                            # 加权过渡后的重叠部分的动作
                            blended = w_old * np.array(old_actions[i]) + w_new * chunk_actions[i]
                            self.action_queue.append(blended)
                        
                        # 新chunk中超出重叠区域的部分直接放入
                        for i in range(overlap, len(chunk_actions)):
                            self.action_queue.append(chunk_actions[i])
                
                self.inference_count += 1
                self.last_inference_ms = (time.perf_counter() - t0) * 1000
                print(f"  [推理#{self.inference_count}] {self.last_inference_ms:.0f}ms, "
                      f"产出{len(chunk_actions)}步, 队列:{len(self.action_queue)}")
                      
            except Exception as e:
                print(f"[推理异常] {e}")
                time.sleep(0.1)
    

    def get_latest_action(self):
        """主线程调用：从队列头部取出一步动作（FIFO）"""
        with self.lock:
            if self.action_queue:
                return self.action_queue.popleft()
            return None  # 队列空，返回None（主线程保持不动）

    def stop(self):
        """停止线程，安全回收资源"""
        self.running = False
        self.thread.join(timeout=5)



# ==============================================================================
# 主函数：100Hz伺服控制 + 安全逻辑 + 界面显示
# ==============================================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy-path", type=str, required=True, help="本地SmolVLA模型路径")
    parser.add_argument("--task", type=str, default="pick up the blue block and place it into the box", help="任务指令")
    parser.add_argument("--robot-ip", type=str, default="192.168.58.2", help="机器人IP")
    parser.add_argument("--cam-idx", type=int, default=6, help="摄像头编号")
    parser.add_argument("--device", type=str, default="cuda", help="cuda/cpu")
    parser.add_argument("--max-steps", type=int, default=500, help="最大运行步数") #就是机械臂此次任务所能执行的最大时间
    parser.add_argument("--control-hz", type=int, default=50, help="ServoJ发送频率(100Hz最稳)")
    parser.add_argument("--inference-hz", type=int, default=10, help="模型推理频率(不需要高)")
    parser.add_argument("--max-joint-delta", type=float, default=1.0, help="单步最大关节变化，安全限制")
    parser.add_argument("--grip-close-force", type=int, default=85, help="闭合力度(0-100)，默认85")
    parser.add_argument("--dry-run", action="store_true", help="只推理不控制机械臂")
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    # ==========================
    # 1. 加载 SmolVLA 模型
    # ==========================
    print("[1] 加载模型...")
    from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
    from lerobot.policies.factory import make_pre_post_processors

    # 从本地加载模型
    policy = SmolVLAPolicy.from_pretrained(args.policy_path)
    policy.to(device)
    # 切换到推理模式
    policy.eval()

    # 数据预处理 / 后处理（归一化、反归一化）
    preprocessor, postprocessor = make_pre_post_processors(
        policy_cfg=policy.config,
        pretrained_path=args.policy_path,
        preprocessor_overrides={"device_processor": {"device": str(device)}},
    )

    # 重置模型缓存
    policy.reset()
    preprocessor.reset()
    postprocessor.reset()
    print("  ✓ 模型就绪")

    # ==========================
    # 2. 连接法奥3机械臂
    # ==========================
    print("[2] 连接机械臂...")
    robot = RPC(args.robot_ip)
    time.sleep(1.5)
    robot.ResetAllError()       # 清除错误
    robot.RobotEnable(1)        # 使能
    time.sleep(0.3)
    robot.Mode(0)               # 0=位置模式
    time.sleep(0.3)

    # 读取初始关节
    err, init_joints = robot.GetActualJointPosDegree()
    # 因为这里在读取夹爪位置时可能会出现一些bug，导致夹爪的实际状态和度到的不一致，最终导致输入到模型中的状态和图像拍摄到的不一致，模型输出异常，感到困惑
    # init_grip = float(robot.robot_state_pkg.gripper_position) / 100.0
    init_grip = 0.0
    
    print(f"  ✓ 初始位置就绪")

    # ==========================
    # 3. 启动摄像头
    # ==========================
    print("[3] 启动摄像头...")
    camera = CameraThread(args.cam_idx)
    time.sleep(0.5)

    # ==========================
    # 4. 任务信息确认
    # ==========================
    print(f"\n{'='*60}")
    print(f"🤖 异步推理部署")
    print(f"任务: \"{args.task}\"")
    print(f"控制频率: {args.control_hz}Hz | 推理频率: {args.inference_hz}Hz")
    print(f"夹爪闭合力: {args.grip_close_force}% | Dry-run: {args.dry_run}")
    print(f"安全限制: 每步最大 {args.max_joint_delta}° | 最大步数: {args.max_steps}")
    print(f"{'='*60}")

    confirm = input("确认开始? (yes/no): ")
    if confirm.lower() != "yes":
        camera.stop()
        robot.CloseRPC()
        return

    # ==========================
    # 5. 启动后台推理线程
    # ==========================
    print("[4] 启动推理线程...")
    inferencer = InferenceThread(
        policy, preprocessor, postprocessor, device,
        camera, robot, args.task)
    time.sleep(1.0)  # 等待第一次推理完成

    # 【新增】初始化夹爪状态
    inferencer.set_grip_state(0.0)  # 初始为张开

    # ==========================
    # 6. 20Hz 主控制循环
    # ==========================
    if not args.dry_run:
        robot.ServoMoveStart()   # 启动伺服模式，否则就不启动伺服模型，后面的指令也就下发不下去
        time.sleep(0.02)

    target_joints = list(init_joints)
    current_grip = init_grip

    dt = 1.0 / args.control_hz
    step = 0
    last_action = None
    smoothed_action = None                    # 新增：平滑后的动作

    grip_confirm_counter = 0
    grip_pending_state = None  # None / "close" / "open"
    GRIP_CONFIRM_STEPS = 5     # 连续5步(在50Hz下即0.1秒)确认才执行

    print("\n[开始执行] Ctrl+C 或 ESC 中断")

    try:
        while step < args.max_steps:
            t0 = time.perf_counter()

            # 从推理队列获取最新动作
            new_action = inferencer.get_latest_action()
            if new_action is not None:
                last_action = new_action
                # ==================== 新增：指数平滑（低通滤波） ====================
                 # ============ 修改：只对关节角度做平滑，夹爪维度完全不平滑 ============
                #  因为对再训练时夹爪做了二值处理，所以如果平滑了就不是二值，就会反复触发开关阈值
                new_arr = np.array(new_action, dtype=float)

                if smoothed_action is None:
                    smoothed_action = new_arr.copy()
                else:
                    # 只平滑前6个关节维度
                    smoothed_action[:6] = 0.85 * smoothed_action[:6] + 0.15 * new_arr[:6]
                    # 夹爪维度[6]直接使用原始值，不做平滑
                    smoothed_action[6] = new_arr[6]

                last_action = smoothed_action.tolist()
                # =====================================================

            # 还没收到动作 → 保持不动
            if last_action is None:
                if not args.dry_run:
                    # 机械臂保持最后一次的目标位置，不动
                    robot.ServoJ(target_joints, [0, 0, 0, 0],
                                 acc=0.0, vel=0.0, cmdT=dt, filterT=0.0)
                time.sleep(dt)
                continue

            # --------------------------
            # 安全限制：单步关节不能突变太大
            # --------------------------
            desired = last_action[:6]
            for i in range(6):
                delta = desired[i] - target_joints[i]
                if abs(delta) > args.max_joint_delta:
                    # 5. 不让它转那么多！只允许转最大安全角度——安全截断
                    # np.sign() = 只看数字的【正负方向】，不看大小，返回1/-1/0
                    desired[i] = target_joints[i] + np.sign(delta) * args.max_joint_delta
            target_joints = list(desired)

            # --------------------------
            # 新版夹爪逻辑：1=闭合 0=张开
            # --------------------------
            grip_value = float(last_action[6]) if len(last_action) >= 7 else 0.0
            grip_changed = False
            grip_percent = 0

            GRIP_CLOSE_THRESHOLD = 0.65
            GRIP_OPEN_THRESHOLD = 0.35

            # 判断意图
            # current_grip是当前的夹爪状态，如果当前的夹爪实际状态是打开，并且模型输出的夹爪状态预测是大于0.65，也就是模型认为此时夹爪应该闭合
            # 那就把模型意图状态设置为close
            if current_grip < 0.5 and grip_value > GRIP_CLOSE_THRESHOLD:
                intended = "close"
            elif current_grip >= 0.5 and grip_value < GRIP_OPEN_THRESHOLD:
                intended = "open"
            # 如果是其他情况，也就是夹爪当前是打开，模型输出也认为该打开，或者模型输出的值在0.35~0.65之间，则认为模型此时没有想改变夹爪状态的意图
            else:
                intended = None
                grip_confirm_counter = 0 #消除模型输出抖动的影响（比如夹爪在关闭状态是，模型预测也是关闭状态，突然模型抖动输出了打开的预测，意图就会变成打开，但是这个是噪声跳变，不会持续，所以连续确认机制就发挥作用）
                grip_pending_state = None

            # 连续确认机制
            if intended is not None: #说明一定是close或者open的一种
                # 其实grip_pending_state就是intended的上一次状态
                if intended == grip_pending_state:
                    grip_confirm_counter += 1
                else:
                    grip_pending_state = intended
                    grip_confirm_counter = 1
                
                # 如果连续几次，模型的意图都是同一个，则说明模型是真的像让夹爪的状态改变，不是噪声突变
                if grip_confirm_counter >= GRIP_CONFIRM_STEPS:
                    grip_changed = True
                    if intended == "close":
                        grip_percent = args.grip_close_force
                        current_grip = 1.0
                        # 【关键】立即同步给推理线程（新增夹爪状态由软件读取——自己设定的，会有滞后性——这是用于输入模型的状态）
                        inferencer.set_grip_state(1.0)

                        print(f"  Step {step:4d} | 夹爪【闭合】 (model_grip={grip_value:.3f}, confirmed)")
                    else:
                        grip_percent = 0
                        current_grip = 0.0
                         # 【关键】立即同步给推理线程
                        inferencer.set_grip_state(0.0)
                        print(f"  Step {step:4d} | 夹爪【张开】 (model_grip={grip_value:.3f}, confirmed)")
                    grip_confirm_counter = 0
                    grip_pending_state = None

           # 推理端夹爪逻辑（二值化版本，替换原来复杂的滞回逻辑——因为新版的数据采集程序，只让模型学习夹爪的二值信息！）
            # grip_value = float(last_action[6]) if len(last_action) >= 7 else 0.0

            # grip_changed = False
            # grip_percent = 0

            # # 简单阈值判断：> 0.5 就是闭合，< 0.5 就是打开
            # if grip_value > 0.5 and prev_grip_model <= 0.5:
            #     grip_changed = True
            #     grip_percent = args.grip_close_force
            #     current_grip = 1.0
            #     print(f"  Step {step:4d} | 夹爪【闭合】 (model_grip={grip_value:.3f})")

            # elif grip_value <= 0.5 and prev_grip_model > 0.5:
            #     grip_changed = True
            #     grip_percent = 0
            #     current_grip = 0.0
            #     print(f"  Step {step:4d} | 夹爪【张开】 (model_grip={grip_value:.3f})")

            # prev_grip_model = grip_value
            # =============================================================

            # 原程序：
            # # 张开 → 闭合
            # grip_value = float(last_action[6]) if len(last_action) >= 7 else current_grip
            # grip_changed = False

            # if prev_grip >= grip_threshold and grip_value < grip_threshold:
            #     grip_changed = True
            #     grip_percent = 0
            #     current_grip = 0.0
            # elif prev_grip < grip_threshold and grip_value >= grip_threshold:
            #     grip_changed = True
            #     grip_percent = 100
            #     current_grip = 1.0
            # prev_grip = grip_value

            # --------------------------
            # 下发指令给机械臂
            # --------------------------
            if not args.dry_run:
                if grip_changed:
                    # 夹爪状态变化 → 退出伺服，运动夹爪，再重启伺服
                    robot.ServoMoveEnd()
                    time.sleep(0.02)
                    robot.MoveGripper(1, grip_percent, 80, 50, 30000, 1, 0, 0, 0, 0)
                    name = "闭合" if grip_percent > 50 else "张开"
                    print(f"  Step {step}: 夹爪{name}")
                    time.sleep(0.3)
                    robot.ResetAllError()
                    time.sleep(0.05)
                    # 更新当前真实关节
                    err, cur = robot.GetActualJointPosDegree()
                    if err == 0:
                        target_joints = list(cur)
                    # 【重要】清空队列中的旧动作！
                    # 夹爪操作消耗了时间，队列中的旧动作已经过时了
                    # with inferencer.lock:
                    #     inferencer.action_queue.clear()

                    robot.ServoMoveStart() #夹爪在运动过程中，主程序会卡在这一步，直到夹爪运动完毕，才会从这一步继续往下执行！
                    time.sleep(0.02)
                    print("4")
                else:
                    # 正常伺服运动
       
                    robot.ServoJ(target_joints,[0, 0, 0, 0],
                                 acc=0.0, vel=0.0, cmdT=dt, filterT=0.0)
                 
            # --------------------------
            # 日志输出
            # --------------------------
            # if step % 10 == 0:
            j_str = ", ".join([f"{v:.1f}" for v in target_joints])
            print(f"  Step {step:4d} | 推理次数#{inferencer.inference_count} "
                    f"| 主循环执行耗时:{time.perf_counter() - t0:.0f}ms | [{j_str}] | grip={grip_value:.2f}")

            # --------------------------
            # 实时画面显示
            # --------------------------
            if step % 10 == 0:
                frame = camera.get_frame()
                if frame is not None:
                    display = cv2.resize(frame, (400, 400))
                    cv2.putText(display, f"AUTO Step {step}", (5, 25),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
                    cv2.imshow("FA3", display)
                    if cv2.waitKey(1) & 0xFF == 27:
                        break

            step += 1
            # 固定20Hz
            elapsed = time.perf_counter() - t0
            if elapsed < dt:
                time.sleep(dt - elapsed)

    except KeyboardInterrupt:
        print("\n用户中断")

    finally:
        # 安全停机流程
        print("正在安全停止...")
        inferencer.stop()
        if not args.dry_run:
            robot.ServoMoveEnd()
            time.sleep(0.3)
        camera.stop()
        cv2.destroyAllWindows()
        robot.CloseRPC()
        print(f"✅ 完成, 共 {step} 步, 推理 {inferencer.inference_count} 次")


if __name__ == "__main__":
    main()
