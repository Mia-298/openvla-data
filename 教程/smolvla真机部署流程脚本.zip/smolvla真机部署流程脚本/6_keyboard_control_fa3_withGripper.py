# 6_keyboard_control_fa3_withGripper.py
import sys
import time
import threading

try:
    from pynput import keyboard
except ImportError:
    print("请安装: pip install pynput")
    sys.exit(1)

from Robot import RPC


class FA3KeyboardController:
    KEY_MAP = {
        '1': (0, +1), 'q': (0, -1),
        '2': (1, +1), 'w': (1, -1),
        '3': (2, +1), 'e': (2, -1),
        '4': (3, +1), 'r': (3, -1),
        '5': (4, +1), 't': (4, -1),
        '6': (5, +1), 'y': (5, -1),
    }
    JOINT_NAMES = ["J1", "J2", "J3", "J4", "J5", "J6"]

    def __init__(self, ip="192.168.58.2"):
        self.ip = ip
        self.running = False
        self.pressed_keys = set()
        self.lock = threading.Lock()
        self.robot = None

        self.speed_deg_per_sec = 10.0
        self.target_joints = [0.0] * 6

        # 夹爪: None=无指令待发, "open"=待张开, "close"=待闭合
        self.gripper_command = None
        self.gripper_position_percent = 0

    def connect(self):
        print(f"连接机器人 {self.ip}...")
        self.robot = RPC(self.ip)
        time.sleep(1.5)

        if not RPC.is_conect:
            raise ConnectionError("连接失败")

        self.robot.ResetAllError()
        self.robot.RobotEnable(1)
        time.sleep(0.3)
        self.robot.Mode(0)
        time.sleep(0.3)

        err, current = self.robot.GetActualJointPosDegree()
        if err == 0:
            self.target_joints = list(current)
        else:
            raise RuntimeError("无法读取初始关节位置")

        self.gripper_position_percent = self.robot.robot_state_pkg.gripper_position
        print(f"[OK] 机器人已连接, 夹爪: {self.gripper_position_percent}%")

    def _on_press(self, key):
        try:
            k = key.char
        except:
            k = None

        if k:
            with self.lock:
                self.pressed_keys.add(k)

            if k == '=' or k == '+':
                self.speed_deg_per_sec = min(self.speed_deg_per_sec + 2.0, 30.0)
                print(f"速度: {self.speed_deg_per_sec:.1f} 度/秒")
            elif k == '-':
                self.speed_deg_per_sec = max(self.speed_deg_per_sec - 2.0, 2.0)
                print(f"速度: {self.speed_deg_per_sec:.1f} 度/秒")
            elif k == 'o':
                self.gripper_command = "open"
            elif k == 'c':
                self.gripper_command = "close"
            elif k == '0':
                self._print_status()

        if key == keyboard.Key.esc:
            self.running = False

    def _on_release(self, key):
        try:
            k = key.char
        except:
            k = None
        if k:
            with self.lock:
                self.pressed_keys.discard(k)

    def _print_status(self):
        err, joints = self.robot.GetActualJointPosDegree()
        grip = self.robot.robot_state_pkg.gripper_position
        if err == 0:
            print("当前状态:")
            for n, v in zip(self.JOINT_NAMES, joints):
                print(f"  {n}: {v:.3f}°")
            print(f"  夹爪: {grip}%")

    def run(self):
        self.connect()

        err = self.robot.ServoMoveStart()
        if err != 0:
            print(f"[FAIL] ServoMoveStart错误: {err}")
            return

        listener = keyboard.Listener(on_press=self._on_press, on_release=self._on_release)
        listener.start()
        self.running = True

        print("\n" + "=" * 55)
        print("丝滑键盘控制 (含夹爪)")
        print("关节: 1/q(J1) 2/w(J2) 3/e(J3) 4/r(J4) 5/t(J5) 6/y(J6)")
        print("夹爪: o(张开)  c(闭合)")
        print("+/-: 调速  0: 显示状态  ESC: 退出")
        print("=" * 55)

        loop_rate = 100
        dt = 1.0 / loop_rate
        gripper_cooldown = 0  # 夹爪发送冷却计数器

        try:
            while self.running:
                t0 = time.perf_counter()

                # --- 1. 处理夹爪指令 (在主线程中, 与ServoJ串行执行) ---
                if self.gripper_command and gripper_cooldown <= 0:
                    # 先结束ServoMove, 发送夹爪, 再重启ServoMove
                    self.robot.ServoMoveEnd()
                    time.sleep(0.02)

                    if self.gripper_command == "open":
                        self.robot.MoveGripper(1, 100, 50, 50, 30000, 0, 0, 0, 0, 0)
                        self.gripper_position_percent = 100
                        print("夹爪: 张开")
                    elif self.gripper_command == "close":
                        self.robot.MoveGripper(1, 0, 50, 50, 30000, 0, 0, 0, 0, 0)
                        self.gripper_position_percent = 0
                        print("夹爪: 闭合")

                    self.gripper_command = None
                    gripper_cooldown = 50  # 0.5秒冷却, 防止连续触发

                    # 等待夹爪动作开始执行
                    time.sleep(0.5)

                    # 重新读取当前位置作为新基准 (防止漂移)
                    err, current = self.robot.GetActualJointPosDegree()
                    if err == 0:
                        self.target_joints = list(current)

                    # 重启ServoMove
                    self.robot.ServoMoveStart()
                    time.sleep(0.02)

                if gripper_cooldown > 0:
                    gripper_cooldown -= 1

                # --- 2. 100Hz 关节控制 ---
                with self.lock:
                    keys = set(self.pressed_keys)

                for k in keys:
                    if k in self.KEY_MAP:
                        joint_idx, direction = self.KEY_MAP[k]
                        self.target_joints[joint_idx] += direction * self.speed_deg_per_sec * dt

                self.robot.ServoJ(self.target_joints, [0, 0, 0, 0],
                                  acc=0.0, vel=0.0, cmdT=dt, filterT=0.0)

                # --- 3. 时钟控制 ---
                elapsed = time.perf_counter() - t0
                if elapsed < dt:
                    time.sleep(dt - elapsed)

        except KeyboardInterrupt:
            pass
        finally:
            print("\n正在停止...")
            listener.stop()
            self.robot.ServoMoveEnd()
            time.sleep(0.2)
            self.robot.CloseRPC()
            print("[OK] 已退出")


if __name__ == "__main__":
    ip = sys.argv[1] if len(sys.argv) > 1 else "192.168.58.2"
    controller = FA3KeyboardController(ip)
    controller.run()