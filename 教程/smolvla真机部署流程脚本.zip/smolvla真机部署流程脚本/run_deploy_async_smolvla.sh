#!/bin/bash

# 原来30条基础能力训练的模型
python 10_deploy_fa3_async.py \
  --policy-path=/home/zjs/Learning_lerobot/lerobot/zjs_test/outputs/new_datasets_finetune4_batch32_setp8000/008000/pretrained_model \
  --task="put duck toy in paper cup" \
  --max-steps=500 \
  --max-joint-delta=0.8 \
  --control-hz=20


# 新增了空间泛化数据（20条）之后的继续训练的模型
# python 10_deploy_fa3_async.py \
#   --policy-path=/home/zjs/Learning_lerobot/lerobot/zjs_test/outputs/fa3_smolvla_onetask_finetune_final5_merged_spatial/006000/pretrained_model \
#   --task="put duck toy in paper cup" \
#   --max-steps=370 \
#   --max-joint-delta=0.8 \
#   --control-hz=20

# 新增了空间泛化数据（20条）之后的重新基于base训练的模型
# python 10_deploy_fa3_async.py \
#   --policy-path=/home/zjs/Learning_lerobot/lerobot/zjs_test/outputs/003000/pretrained_model \
#   --task="put duck toy in paper cup" \
#   --max-steps=400 \
#   --max-joint-delta=0.8 \
#   --control-hz=20

