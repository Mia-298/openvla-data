#!/usr/bin/env python3
# 7_keyboard_record_fa3_cart_v2.py
"""
【改进版】笛卡尔空间键盘控制法奥3 + 数据采集
改进点：
  1. 自动跳过静止帧（连续静止 > 0.5秒后跳过）
  2. 实时录制质量监控面板
  3. Episode质量评分（保存时自动评估）
  4. 操作速度实时提醒

保留原有全部功能：
  - 笛卡尔空间增量运动 (ServoCart mode=2)
  - 多任务数据采集 + 一键废弃
  - 异步无感录制 + 语言指令泛化
  - 非阻塞夹爪 + SDK延迟修复

平移控制 (工具坐标系):
  A/D : X+ / X-  (前/后)
  S/W : Y+ / Y-  (左右)
  F/R : Z+ / Z-  (上下)

旋转控制 (工具坐标系):
  K/I : RX+ / RX-
  L/J : RY+ / RY-
  U/M : RZ+ / RZ-

夹爪: O(张开)  C(闭合)
速度: +/- 调节平移速度    [/] 调节旋转速度
录制: SPACE(开始/保存)    切换任务: TAB
废弃: Backspace (删除当前正在录制的烂数据)
退出: ESC

数据集格式: observation.state=[j1..j6, gripper], action=[j1..j6, gripper] (7维)
"""
import sys
import time
import cv2
import threading
import queue
import numpy as np
import random

try:
    from pynput import keyboard
except ImportError:
    print("请安装: pip install pynput")
    sys.exit(1)

from lerobot.datasets.lerobot_dataset import LeRobotDataset
from Robot import RPC

TASKS = {
    "Task 1: Duck -> Cup": [
        "pick up the toy duck and place it into the paper cup",
        "put the yellow duck inside the cup",
        "grab the duck and drop it in the paper cup",
        "move the yellow toy duck to the cup",
        "place the duck into the cup"
    ],
    "Task 2: Snack -> Box": [
        "put a pack of snacks into the box",
        "pick up the yellow snack packet and place it inside the box",
        "grab the snacks and drop them in the container",
        "move the snack packet to the box",
        "place the yellow snack into the container"
    ]
}
TASK_GROUPS = list(TASKS.keys())

IMG_SIZE = 256


class CameraThread:
    def __init__(self, cam_idx):
        self.cap = cv2.VideoCapture(cam_idx, cv2.CAP_V4L2)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.latest_frame = None
        self.lock = threading.Lock()
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def _loop(self):
        while self.running:
            ret, frame = self.cap.read()
            if ret:
                with self.lock:
                    self.latest_frame = frame

    def get_frame(self):
        with self.lock:
            return self.latest_frame.copy() if self.latest_frame is not None else None

    def stop(self):
        self.running = False
        self.thread.join(timeout=2)
        self.cap.release()

# 质量监控
class EpisodeQualityMonitor:
    """录制质量实时监控器"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.total_sample_points = 0      # 总采样点（10Hz触发次数）
        self.recorded_frames = 0          # 实际录制的帧数
        self.skipped_frames = 0           # 跳过的静止帧数
        self.gripper_changes = 0          # 夹爪状态变化次数
        self.start_time = None
        self.all_actions = []             # 记录所有action用于质量评估
        self.last_state = None
        self.max_joint_range = np.zeros(7)  # 各关节最大运动范围
        self.min_joints = np.full(7, 999.0)
        self.max_joints = np.full(7, -999.0)
        self.idle_warnings = 0            # 长时间静止警告次数

    def on_frame_recorded(self, state, action):
        """记录一帧有效数据"""
        self.recorded_frames += 1
        self.all_actions.append(np.array(action))

        state_np = np.array(state)
        self.min_joints = np.minimum(self.min_joints, state_np)
        self.max_joints = np.maximum(self.max_joints, state_np)
        self.max_joint_range = self.max_joints - self.min_joints

        if self.last_state is not None:
            grip_changed = abs(state[6] - self.last_state[6]) > 0.3
            if grip_changed:
                self.gripper_changes += 1
        self.last_state = list(state)

    def on_frame_skipped(self):
        """记录跳过一帧"""
        self.skipped_frames += 1

    def on_sample_point(self):
        """10Hz采样点触发"""
        self.total_sample_points += 1

    def start(self):
        self.reset()
        self.start_time = time.perf_counter()

    # 计算持续时间 
    def get_duration(self):
        if self.start_time is None:
            return 0
        return time.perf_counter() - self.start_time

    def get_quality_score(self):
        """计算质量评分 (0-100)"""
        if self.recorded_frames < 10:
            return 0

        score = 0
        duration = self.get_duration()

        # 1. 时长评分 (满分25): 15-25秒最佳
        if 12 <= duration <= 30:
            score += 25
        elif 8 <= duration < 12:
            score += 15
        elif 30 < duration <= 45:
            score += 15
        else:
            score += 5

        # 2. 有效帧率 (满分25): 跳过率越低越好
        if self.total_sample_points > 0:
            effective_rate = self.recorded_frames / self.total_sample_points
            score += int(effective_rate * 25)

        # 3. 夹爪变化 (满分25): 至少2次（开→闭→开）
        if self.gripper_changes >= 2:
            score += 25
        elif self.gripper_changes >= 1:
            score += 15
        else:
            score += 0

        # 4. 关节运动幅度 (满分25): 前6个关节都有足够运动
        joint_moved = sum(1 for i in range(6) if self.max_joint_range[i] > 5.0)
        score += int(joint_moved / 6 * 25)

        return min(100, score)

    def get_quality_report(self):
        """生成质量报告"""
        duration = self.get_duration()
        score = self.get_quality_score()
        total = self.total_sample_points
        skip_rate = (self.skipped_frames / total * 100) if total > 0 else 0
        eff_fps = self.recorded_frames / duration if duration > 0 else 0

        report = f"\n{'='*60}\n"
        report += f"  📊 Episode 质量报告\n"
        report += f"{'='*60}\n"
        report += f"  录制时长: {duration:.1f}秒\n"
        report += f"  总采样点: {total} | 有效帧: {self.recorded_frames} | 跳过: {self.skipped_frames}\n"
        report += f"  有效帧率: {eff_fps:.1f} FPS | 静止跳过率: {skip_rate:.1f}%\n"
        report += f"  夹爪变化: {self.gripper_changes}次\n"
        report += f"  关节运动范围:\n"

        labels = ["J1", "J2", "J3", "J4", "J5", "J6", "Grip"]
        for i, label in enumerate(labels):
            r = self.max_joint_range[i]
            bar = "█" * min(int(r / 3), 20)
            report += f"    {label:4s}: {r:6.1f}° {bar}\n"

        report += f"\n  综合评分: {score}/100 "
        if score >= 80:
            report += "✅ 优秀"
        elif score >= 60:
            report += "⚠️ 合格"
        elif score >= 40:
            report += "⚠️ 一般（建议重录）"
        else:
            report += "❌ 较差（强烈建议重录）"

        # 具体建议
        if duration > 30:
            report += "\n  💡 建议: 录制时间偏长，操作再流畅些"
        if skip_rate > 40:
            report += "\n  💡 建议: 静止帧过多，减少观察停顿"
        if self.gripper_changes < 2:
            report += "\n  💡 建议: 夹爪动作不完整，确保有 开→闭→开 的完整流程"

        report += f"\n{'='*60}"
        return report

# 主控制器
class FA3CartRecorder:
    CART_KEY_MAP = {
        'w': (0, +1), 's': (0, -1),
        'a': (1, +1), 'd': (1, -1),
        'f': (2, +1), 'r': (2, -1),
        'j': (3, +1), 'l': (3, -1),
        'i': (4, +1), 'k': (4, -1),
        'u': (5, +1), 'p': (5, -1),
    }
    STATE_NAMES = ["j1", "j2", "j3", "j4", "j5", "j6", "gripper"]

    def __init__(self, ip="192.168.58.2", cam_idx=6,
                 repo_id="local/fa3_smolvla_multitask"):
        self.ip = ip
        self.cam_idx = cam_idx
        self.repo_id = repo_id

        self.current_group_idx = 0
        self.current_group_name = TASK_GROUPS[0]
        self.current_episode_prompt = ""

        self.control_hz = 20
        self.record_fps = 10

        self.linear_speed = 50.0       # 默认提高到50（加快操作速度）
        self.angular_speed = 10.0

        self.gripper_command = None
        self.gripper_target_normalized = 0.0

        # 非阻塞夹爪状态机变量
        self.gripper_moving_state = False
        self.gripper_target_pct = 0
        self.gripper_wait_start = 0

        # SDK延迟修复
        self.gripper_start_pct = 0
        self.gripper_sdk_delay = 1.0
        self.gripper_total_duration = 3.0
        self.last_valid_gripper_pct = 0

        # 缓存关节角度
        self.last_valid_joints = [0.0] * 6

        # ============ 新增：静止帧跳过 ============
        self.max_idle_frames = 5        # 最多连续录制5帧静止（0.5秒）
        self.idle_frame_count = 0       # 当前连续静止帧计数
        self.last_idle_warning = 0      # 上次静止警告时间

        # ============ 新增：质量监控器 ============
        self.quality_monitor = EpisodeQualityMonitor()

        self.running = True
        self.record_state = "IDLE"
        self.pressed_keys = set()
        self.lock = threading.Lock()

        self.task_episode_counts = {g: 0 for g in TASK_GROUPS}

        self.dataset_queue = queue.Queue()
        self.dataset_thread = threading.Thread(target=self._dataset_worker, daemon=True)

    def _dataset_worker(self):
        while self.running:
            try:
                msg = self.dataset_queue.get(timeout=0.1)
                cmd = msg["cmd"]

                if cmd == "add":
                    frame_resized = cv2.resize(msg["frame"], (IMG_SIZE, IMG_SIZE))
                    frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
                    self.dataset.add_frame({
                        "observation.images.top": frame_rgb,
                        "observation.state": np.array(msg["state"], dtype=np.float32),
                        "action": np.array(msg["action"], dtype=np.float32),
                        "task": msg["task"],
                    })
                elif cmd == "save":
                    self.dataset.save_episode()
                    self.dataset.clear_episode_buffer()
                    print(f"\n✅ 已保存! 当前数据集总录制: {self.dataset.num_episodes} 条")
                elif cmd == "clear":
                    self.dataset.clear_episode_buffer()
                    print(f"\n❌ 已废弃! 当前正在录制的数据已清空。")
                elif cmd == "finalize":
                    self.dataset.finalize()

            except queue.Empty:
                pass

    def _get_gripper_pct(self):
        if not self.gripper_moving_state:
            raw = float(self.robot.robot_state_pkg.gripper_position)
            self.last_valid_gripper_pct = raw
            return raw

        elapsed = time.perf_counter() - self.gripper_wait_start

        if elapsed < self.gripper_sdk_delay:
            progress = elapsed / self.gripper_total_duration
            progress = min(progress, 1.0)
            interpolated = self.gripper_start_pct + (self.gripper_target_pct - self.gripper_start_pct) * progress
            self.last_valid_gripper_pct = interpolated
            return interpolated
        else:
            raw = float(self.robot.robot_state_pkg.gripper_position)
            self.last_valid_gripper_pct = raw
            return raw

    def connect(self):
        print(f"连接机器人 {self.ip}...")
        self.robot = RPC(self.ip)
        time.sleep(1.5)

        self.robot.ResetAllError()
        self.robot.RobotEnable(1)
        time.sleep(0.3)
        self.robot.Mode(0)
        time.sleep(0.3)

        err, tcp = self.robot.GetActualTCPPose()
        if err == 0:
            print(f"  初始TCP: X={tcp[0]:.1f} Y={tcp[1]:.1f} Z={tcp[2]:.1f}")

        err_j, joints_init = self.robot.GetActualJointPosDegree()
        if err_j == 0:
            self.last_valid_joints = list(joints_init)

        init_grip = float(self.robot.robot_state_pkg.gripper_position)
        self.last_valid_gripper_pct = init_grip
        self.gripper_target_normalized = init_grip / 100.0
        self.robot.ServoMoveStart()

        self.camera = CameraThread(self.cam_idx)

        features = {
            "observation.images.top": {
                "dtype": "video",
                "shape": (IMG_SIZE, IMG_SIZE, 3),
                "names": ["height", "width", "channel"],
            },
            "observation.state": {
                "dtype": "float32",
                "shape": (7,),
                "names": self.STATE_NAMES,
            },
            "action": {
                "dtype": "float32",
                "shape": (7,),
                "names": self.STATE_NAMES,
            },
        }
        self.dataset = LeRobotDataset.create(
            repo_id=self.repo_id,
            fps=self.record_fps,
            robot_type="fa3",
            features=features,
            use_videos=True,
        )
        self.dataset.clear_episode_buffer()

        self.dataset_thread.start()

    def _switch_task(self):
        if self.record_state == "RECORDING":
            print("[警告] 录制中不能切换任务")
            return
        self.current_group_idx = (self.current_group_idx + 1) % len(TASK_GROUPS)
        self.current_group_name = TASK_GROUPS[self.current_group_idx]
        count = self.task_episode_counts[self.current_group_name]
        print(f"\n📋 切换任务组 [{self.current_group_idx+1}/{len(TASK_GROUPS)}]")
        print(f"   \"{self.current_group_name}\" (该组已录 {count} 条)")

    def _on_press(self, key):
        try:
            k = key.char
        except:
            k = None

        if k:
            with self.lock:
                self.pressed_keys.add(k)

            if k == '=' or k == '+':
                self.linear_speed = min(self.linear_speed + 5.0, 100.0)
                print(f"平移速度: {self.linear_speed:.0f} mm/s")
            elif k == '-':
                self.linear_speed = max(self.linear_speed - 5.0, 5.0)
                print(f"平移速度: {self.linear_speed:.0f} mm/s")
            elif k == ']':
                self.angular_speed = min(self.angular_speed + 2.0, 30.0)
                print(f"旋转速度: {self.angular_speed:.0f} °/s")
            elif k == '[':
                self.angular_speed = max(self.angular_speed - 2.0, 2.0)
                print(f"旋转速度: {self.angular_speed:.0f} °/s")
            elif k == 'o':
                self.gripper_command = "open"
            elif k == 'c':
                self.gripper_command = "close"
            elif k == '0':
                self._print_status()

        if key == keyboard.Key.tab:
            self._switch_task()

        if key == keyboard.Key.space:
            if self.record_state == "IDLE":
                self.current_episode_prompt = random.choice(TASKS[self.current_group_name])
                self.record_state = "RECORDING"
                self.quality_monitor.start()
                self.idle_frame_count = 0
                print(f"\n[🔴 录制中] 抽取指令: \"{self.current_episode_prompt}\"")
                print(f"  💡 提示: 尽量流畅操作，减少停顿，目标15-25秒完成")
            elif self.record_state == "RECORDING":
                self.record_state = "SAVE_PENDING"
                print(self.quality_monitor.get_quality_report())
                print("\n[⏳ 保存中]...")

        if key == keyboard.Key.backspace:
            if self.record_state == "RECORDING":
                self.record_state = "DISCARD_PENDING"
                print("\n[🗑️ 废弃指令发送中]...")

        if key == keyboard.Key.esc:
            self.running = False

    def _on_release(self, key):
        try:
            k = key.char
        except:
            k = None
        if k:
            with self.lock:
                self.pressed_keys.discard(k)

    def _print_status(self):
        err, tcp = self.robot.GetActualTCPPose()
        err2, joints = self.robot.GetActualJointPosDegree()
        grip = self._get_gripper_pct()
        if err == 0:
            print(f"TCP: X={tcp[0]:.1f} Y={tcp[1]:.1f} Z={tcp[2]:.1f} "
                  f"RX={tcp[3]:.1f} RY={tcp[4]:.1f} RZ={tcp[5]:.1f}")
        if err2 == 0:
            j_str = " ".join([f"J{i+1}={v:.1f}" for i, v in enumerate(joints)])
            print(f"关节: {j_str}")
        print(f"夹爪: {grip:.0f}%")

    def _get_state_and_action_7d(self):
        err, joints = self.robot.GetActualJointPosDegree()
        if err == 0:
            self.last_valid_joints = list(joints)
            joint_values = list(joints)
        else:
            joint_values = list(self.last_valid_joints)

         # ============ 夹爪二值化 ============
        # state.gripper: 根据物理位置二值化
        grip_raw_pct = self._get_gripper_pct()  # 0~100
        grip_state = 1.0 if grip_raw_pct >= 50.0 else 0.0

        # action.gripper: 直接使用操作者的目标意图（已经是0或1）
        grip_action = self.gripper_target_normalized  # 0.0=开, 1.0=闭
        # ====================================

        state_7d = joint_values + [grip_state]
        action_7d = joint_values + [grip_action]
        return state_7d, action_7d

    def _is_moving(self):
        """检测当前是否有运动（键盘按下或夹爪运动中）"""
        with self.lock:
            keys = set(self.pressed_keys)

        has_key = any(k in self.CART_KEY_MAP for k in keys)
        return has_key or self.gripper_moving_state

    def _print_summary(self):
        print("\n📊 各任务统计:")
        total = 0
        for i, g in enumerate(TASK_GROUPS):
            c = self.task_episode_counts[g]
            total += c
            m = " 👈" if i == self.current_group_idx else ""
            print(f"  [{i+1}] {c:3d} 条 | \"{g}\"{m}")
        print(f"  总计: {total} 条")

    def run(self):
        self.connect()
        listener = keyboard.Listener(on_press=self._on_press, on_release=self._on_release)
        listener.start()

        print("\n" + "=" * 65)
        print("🎮 【改进版】笛卡尔空间键盘控制 + 高质量数据采集")
        print("=" * 65)
        print("平移(工具系): A/D(X前后) S/W(Y左右) F/R(Z上下)")
        print("旋转(工具系): K/I(RX)    L/J(RY)    U/P(RZ)")
        print("夹爪: O(开) C(关)  速度: +/-(平移) [/](旋转)")
        print("-----------------------------------------------------------------")
        print("录制: SPACE       | 废弃当前录制: Backspace (退格键)")
        print("切换任务: TAB     | 状态: 0         | 退出: ESC")
        print("-----------------------------------------------------------------")
        print("📌 改进功能: 自动跳过静止帧 | 实时质量监控 | Episode评分")
        print(f"平移速度: {self.linear_speed}mm/s  旋转速度: {self.angular_speed}°/s")
        for i, g in enumerate(TASK_GROUPS):
            m = " 👈" if i == 0 else ""
            print(f"  [{i+1}] \"{g}\"{m}")
        print(f"数据路径: {self.dataset.root}")
        print("=" * 65)

        dt_control = 1.0 / self.control_hz
        record_interval = int(self.control_hz / self.record_fps)
        loop_counter = 0
        gripper_cooldown = 0
        last_display_time = 0

        try:
            while self.running:
                t0 = time.perf_counter()

                # --- 1. 保存与废弃逻辑 ---
                if self.record_state == "SAVE_PENDING":
                    self.dataset_queue.put({"cmd": "save"})
                    self.task_episode_counts[self.current_group_name] += 1
                    self._print_summary()
                    self.record_state = "IDLE"

                elif self.record_state == "DISCARD_PENDING":
                    self.dataset_queue.put({"cmd": "clear"})
                    self.record_state = "IDLE"

                # --- 2. 夹爪控制 (非阻塞状态机) ---
                if self.gripper_command and gripper_cooldown <= 0 and not self.gripper_moving_state:
                    err_cache, joints_cache = self.robot.GetActualJointPosDegree()
                    if err_cache == 0:
                        self.last_valid_joints = list(joints_cache)

                    self.gripper_start_pct = self.last_valid_gripper_pct

                    self.robot.ServoMoveEnd()
                    time.sleep(0.02)

                    if self.gripper_command == "open":
                        self.gripper_target_pct = 0
                        self.robot.MoveGripper(1, 0, 80, 50, 30000, 0, 0, 0, 0, 0)
                        self.gripper_target_normalized = 0.0
                        print(f"夹爪: 开始张开 (起始:{self.gripper_start_pct:.0f}% → 目标:0%)...")
                    elif self.gripper_command == "close":
                        self.gripper_target_pct = 90
                        self.robot.MoveGripper(1, 90, 80, 50, 30000, 0, 0, 0, 0, 0)
                        self.gripper_target_normalized = 1.0
                        print(f"夹爪: 开始闭合 (起始:{self.gripper_start_pct:.0f}% → 目标:90%)...")

                    self.gripper_command = None
                    self.gripper_moving_state = True
                    self.gripper_wait_start = time.perf_counter()

                # 夹爪运动监控
                if self.gripper_moving_state:
                    elapsed_wait = time.perf_counter() - self.gripper_wait_start

                    if elapsed_wait >= self.gripper_sdk_delay:
                        cur_grip = float(self.robot.robot_state_pkg.gripper_position)
                        if abs(cur_grip - self.gripper_target_pct) < 8 or elapsed_wait > 4.0:
                            print(f"夹爪到位: {cur_grip:.0f}%")
                            self.last_valid_gripper_pct = cur_grip
                            self.robot.ResetAllError()
                            time.sleep(0.05)
                            self.robot.ServoMoveStart()
                            time.sleep(0.02)
                            self.gripper_moving_state = False
                            gripper_cooldown = 30

                if gripper_cooldown > 0 and not self.gripper_moving_state:
                    gripper_cooldown -= 1

                # --- 3. 笛卡尔空间增量控制 (100Hz) ---
                if not self.gripper_moving_state:
                    with self.lock:
                        keys = set(self.pressed_keys)

                    delta = [0.0] * 6
                    is_moving = False
                    for k in keys:
                        if k in self.CART_KEY_MAP:
                            dim_idx, direction = self.CART_KEY_MAP[k]
                            if dim_idx < 3:
                                delta[dim_idx] += direction * self.linear_speed * dt_control
                            else:
                                delta[dim_idx] += direction * self.angular_speed * dt_control
                            is_moving = True

                    if is_moving:
                        self.robot.ServoCart(mode=2, desc_pos=delta, cmdT=dt_control)
                    else:
                        self.robot.ServoCart(mode=2, desc_pos=[0, 0, 0, 0, 0, 0], cmdT=dt_control)

                # --- 4. 10Hz 数据录制（带静止帧跳过） ---
                if self.record_state == "RECORDING" and loop_counter % record_interval == 0:
                    state_7d, action_7d = self._get_state_and_action_7d()
                    frame_ref = self.camera.get_frame()

                    self.quality_monitor.on_sample_point()

                    if state_7d is not None and frame_ref is not None:
                        currently_moving = self._is_moving()

                        if currently_moving:
                            # 有运动 → 重置静止计数，正常录制
                            self.idle_frame_count = 0
                            should_record = True
                        else:
                            # 无运动 → 增加静止计数
                            self.idle_frame_count += 1
                            should_record = (self.idle_frame_count <= self.max_idle_frames)

                            # 长时间静止警告（每3秒警告一次）
                            now_warn = time.perf_counter()
                            if self.idle_frame_count > self.max_idle_frames and now_warn - self.last_idle_warning > 3.0:
                                self.last_idle_warning = now_warn
                                self.quality_monitor.idle_warnings += 1
                                idle_sec = self.idle_frame_count / self.record_fps
                                print(f"  ⚠️ 已静止 {idle_sec:.1f}秒，帧被跳过中... (请继续操作)")

                        if should_record:
                            self.dataset_queue.put({
                                "cmd": "add",
                                "frame": frame_ref,
                                "state": state_7d,
                                "action": action_7d,
                                "task": self.current_episode_prompt
                            })
                            self.quality_monitor.on_frame_recorded(state_7d, action_7d)
                        else:
                            self.quality_monitor.on_frame_skipped()

                # --- 5. 画面预览（带质量监控面板） ---
                now = time.perf_counter()
                if now - last_display_time > 0.1:
                    frame = self.camera.get_frame()
                    if frame is not None:
                        display = cv2.resize(frame, (480, 480))

                        if self.record_state == "RECORDING":
                            # 录制状态 + 实时质量信息
                            duration = self.quality_monitor.get_duration()
                            rec_frames = self.quality_monitor.recorded_frames
                            skip_frames = self.quality_monitor.skipped_frames
                            total_sp = self.quality_monitor.total_sample_points
                            eff_rate = (rec_frames / total_sp * 100) if total_sp > 0 else 100

                            text1 = f"REC {duration:.0f}s | frames:{rec_frames} skip:{skip_frames}"
                            text2 = f"eff:{eff_rate:.0f}% | grip_chg:{self.quality_monitor.gripper_changes}"
                            color = (0, 0, 255)

                            cv2.putText(display, text1, (5, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1)
                            cv2.putText(display, text2, (5, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 200, 255), 1)

                            # 静止警告
                            if self.idle_frame_count > self.max_idle_frames:
                                cv2.putText(display, "IDLE - KEEP MOVING!", (5, 470),
                                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                        else:
                            text = f"IDLE | {self.current_group_name[:35]}"
                            color = (0, 255, 0)
                            cv2.putText(display, text, (5, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

                        err, tcp = self.robot.GetActualTCPPose()
                        if err == 0:
                            tcp_text = f"X={tcp[0]:.0f} Y={tcp[1]:.0f} Z={tcp[2]:.0f}"
                            cv2.putText(display, tcp_text, (5, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)

                        cv2.imshow("FA3 Cart Control v2", display)
                        cv2.waitKey(1)
                    last_display_time = now

                loop_counter += 1

                # --- 6. 严格时钟控制 ---
                elapsed = time.perf_counter() - t0
                if elapsed < dt_control:
                    time.sleep(dt_control - elapsed)

        except KeyboardInterrupt:
            pass
        finally:
            print("\n正在清理硬件资源...")
            listener.stop()

            self.robot.ResetAllError()
            time.sleep(0.1)
            self.robot.ServoMoveEnd()
            time.sleep(0.5)
            self.robot.CloseRPC()

            self.camera.stop()
            cv2.destroyAllWindows()

            if self.record_state == "RECORDING":
                print("程序退出，最后半截未完成数据自动丢弃...")
                self.dataset_queue.put({"cmd": "clear"})
            elif self.record_state == "SAVE_PENDING":
                self.dataset_queue.put({"cmd": "save"})

            self.dataset_queue.put({"cmd": "finalize"})

            print("等待数据后台写入磁盘...")
            time.sleep(1.0)
            self.running = False

            print(f"✅ 完全退出! 数据集路径: {self.dataset.root}")


if __name__ == "__main__":
    app = FA3CartRecorder(
        ip="192.168.58.2",
        cam_idx=6,
        repo_id="local/fa3_smolvla_onetask_new_v2",
    )
    app.run()