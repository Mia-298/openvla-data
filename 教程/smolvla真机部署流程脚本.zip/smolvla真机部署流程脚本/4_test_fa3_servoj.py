# test_fa3_servoj.py
"""
测试法奥3的ServoJ伺服控制（推理部署时使用的控制方式）。
会让J6关节来回摆动5度。

!! 注意安全 !! 运行前确保机器人周围无障碍物。
"""
import sys
import time
import math

def test_servoj(ip="192.168.58.2"):
    from Robot import RPC

    print("连接机器人...")
    # 1. 连接机器人控制器
    robot = RPC(ip)
    time.sleep(1.5)

    if not RPC.is_conect:
        print("[FAIL] 连接失败")
        return

    # 2. 机器人初始化（必须）
    robot.ResetAllError()        # 清除所有错误
    robot.RobotEnable(1)         # 电机使能（上电）
    time.sleep(0.5)
    robot.Mode(1)                # 切换到【自动模式0】，ServoJ必须用自动模式(自动模式和手动模式都可以)
    time.sleep(0.3)

    # 3. 读取当前关节角度，作为摆动的中心点
    err, base_joints = robot.GetActualJointPosDegree()
    if err != 0:
        print(f"[FAIL] 读关节失败: {err}")
        robot.CloseRPC()
        return

    print(f"基准关节位置: {[f'{j:.2f}' for j in base_joints]}")

    # 4. 启动实时伺服模式（关键！）
    err = robot.ServoMoveStart()
    if err != 0:
        print(f"[FAIL] ServoMoveStart错误: {err}")
        robot.CloseRPC()
        return

    print("ServoJ控制中 (J6来回摆动5°, 持续3秒)...")

    # 控制参数
    cmd_period = 0.008  # 8ms 发一次指令（125Hz）
    duration = 3.0      # 总共运行3秒
    amplitude = 5.0     # 摆动幅度 ±5度
    freq = 0.5          # 摆动频率 0.5Hz

    t0 = time.perf_counter()
    count = 0

    try:
        # 5. 【核心循环】持续发送目标角度
        while True:
            t = time.perf_counter() - t0
            if t > duration:
                break

            # 复制基准关节角度
            target = list(base_joints)
            # 只让 J6 轴（索引5）做正弦摆动
            target[5] += amplitude * math.sin(2 * math.pi * freq * t)

            # 6. 【核心指令】发送实时关节目标
            err = robot.ServoJ(
                joint_pos=target,         # 目标6轴角度
                axisPos=[0,0,0,0],      # 冗余参数
                cmdT=cmd_period # 指令周期
            )

            if err != 0:
                print(f"  ServoJ错误: {err} (t={t:.2f}s)")

            count += 1
            time.sleep(cmd_period)  # 严格8ms发一次

    except KeyboardInterrupt:
        print("\n用户中断")

    # 7. 停止实时伺服模式
    robot.ServoMoveEnd()
    time.sleep(0.3)

    # 8. 显示结果
    err, final_joints = robot.GetActualJointPosDegree()
    print(f"最终关节位置: {[f'{j:.2f}' for j in final_joints]}")
    print(f"共发送 {count} 条ServoJ指令")

    robot.CloseRPC()
    print("[OK] ServoJ测试完成")

if __name__ == "__main__":
    ip = sys.argv[1] if len(sys.argv) > 1 else "192.168.58.2"

    print("!! 警告: 此脚本会让机器人J6轴来回摆动5° !!")
    confirm = input("确认继续? (yes/no): ")
    if confirm.lower() == "yes":
        test_servoj(ip)
    else:
        print("已取消")
